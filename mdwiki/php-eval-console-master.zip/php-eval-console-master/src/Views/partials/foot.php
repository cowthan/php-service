<script type="text/javascript" src="<?php echo $config['assets_dir']; ?>/js/script.min.js"></script>
</body>
</html>