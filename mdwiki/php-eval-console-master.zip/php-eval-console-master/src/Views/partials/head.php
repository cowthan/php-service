<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>PHP Eval Console</title>
        <meta name="viewport" content="width=device-width">

        <link rel="stylesheet" href="<?php echo $config['assets_dir']; ?>/css/style.min.css" />
        <script type="text/javascript" src="<?php echo $config['assets_dir']; ?>/js/modernizr.js"></script>

    </head>
    <body>